![alt text](https://www.moderatecontent.com/img/logo.png "ModerateContent.com")

### ModerateContent.com - The FREE Content Moderation API (https://www.moderatecontent.com)

Our free API provides a content rating for any image. Detect inappropriate content from adult to violent and more subtle ratings including smoking, alcohol and suggestive.

Examples of consuming the API with javascript using the GET method.