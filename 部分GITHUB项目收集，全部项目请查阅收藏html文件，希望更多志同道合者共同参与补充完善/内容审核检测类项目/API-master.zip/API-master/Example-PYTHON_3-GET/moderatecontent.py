import urllib.request
urllib.request.urlopen("https://www.moderatecontent.com/api/?url=http://www.moderatecontent.com/img/logo.png").read()
