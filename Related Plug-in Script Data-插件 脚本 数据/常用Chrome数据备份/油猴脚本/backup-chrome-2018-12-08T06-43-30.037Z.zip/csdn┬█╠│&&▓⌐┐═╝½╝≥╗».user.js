// ==UserScript==
// @name         csdn论坛&&博客极简化
// @namespace    https://github.com/Gccc9
// @version      2.0
// @description  CSDN论坛,博客(只有正文)  适合不登录者
// @author       Gccc。
// @match        *://blog.csdn.net/*
// @match        *://bbs.csdn.net/topics/*
// ==/UserScript==

(function() {
    'use strict';
    var currentURL = window.location.href;
    var CSDN = /csdn/;
    var CSDN_TALK = /bbs/;
    //若为CSDN论坛,则：
    if(CSDN_TALK.test(currentURL)){
        function function_BBS(){
            document.getElementsByClassName("mod_topic_wrap")[1].style="display:none";//隐藏“csdn”推荐
            document.getElementsByClassName("post_feed_box")[0].style="display:none";//隐藏底部相关文章推荐
            document.getElementsByClassName("news-nav")[0].style="display:none";//隐藏头部栏
            //document.getElementById("csdn-toolbar").style="display:none";//隐藏头部栏
            document.getElementById("layerd_left").style="display:none";//隐藏左下浮框
            document.getElementById("layerd").style="display:none";//隐藏右边浮框
            document.getElementsByClassName("meau-gotop-box")[0].style="display:none";//隐藏右边“vip免广告”图标
            document.getElementById("new_post").style="display:none";//隐藏“匿名用户不能发表回复！”logo
            document.getElementsByClassName("pulllog-box")[0].style="display:none";//隐藏底部栏
            if( document.getElementsByClassName("bottom-pub-footer footer-box")[0] != null ){//隐藏底部的二维码及相关信息
                document.getElementsByClassName("bottom-pub-footer footer-box")[0].style="display:none;";
            }
            if (document.getElementsByClassName("show_topic js_show_topic")[0] != null){
                document.getElementsByClassName("show_topic js_show_topic")[0].click();//点击阅读全文
            }
            var ad = document.getElementsByClassName("mediav_ad");//获取广告的数量
            for(var i = 0 ; i < ad.length ; i++){ //循环去掉每一个广告
                ad[i].style="display:none";
            }
            //去掉两个回复框
            var reply = document.getElementsByClassName("fun_l fr");
            for( i = 0 ; i < reply.length ; i++){
                reply[i].style="display:none";
            }
            //去掉所有“引用”按钮
            var quote = document.getElementsByClassName("quote");
            for( i = 0 ; i < quote.length ; i++){
                quote[i].style="display:none";
            }
            //去掉所有“举报”按钮
            var report_spam = document.getElementsByClassName("report_spam");
            for( i = 0 ; i < report_spam.length ; i++){
                report_spam[i].style="display:none";
            }
        }
        function_BBS();
    }

    //若为CSDN,则：
    if( CSDN.test(currentURL)){
        function function_CSDN(){
            var check = document.getElementsByClassName("pulllog-box")[0];//移除底部绝对位置处的登陆与注册的提醒
            if(check != null ){
                check.style="display:none;";
            }
            check = document.getElementsByTagName("aside")[0];//移除左边全部栏目
            if(check != null ){
                check.style="display:none;";
            }
            check = document.getElementById("csdn-toolbar");//移除顶部的搜索信息栏目
            if(check != null ){
                check.style="display:none;";
            }
            check = document.getElementsByClassName("meau-list")[0];//移除右边工具栏目
            if(check != null ){
                check.style="display:none;";
            }
            check = document.getElementById("adContent");//移除右边“vip免广告”logo
            if(check != null ){
                check.style="display:none;";
            }
            check = document.getElementById("reportContent");//移除右边“举报”logo
            if(check != null ){
                check.style="display:none;";
            }
            document.getElementById("mainBox").style.width="860px";//将文章的内容居中显示
            check = document.getElementsByClassName("unlogin-box text-center")[0];//删除“想对作者说的话”
            if(check != null ){
                check.style="display:none;";
            }

            check = document.getElementsByClassName("recommend-box")[0];//隐藏底部的其他文章栏目
            if(check != null ){
                check.style="display:none;";
            }
            check = document.getElementsByTagName("aside")[0];
            if( check != null ){
                check.remove();
            }
            check = document.getElementById("btn-readmore");//“阅读更多”
            if( check != null ){
                check.click();
            }
            check = document.getElementsByClassName("mediav_ad")[0];//文章下的一条广告
            if(check != null ){
                check.style="display:none;";
            }
            check = document.getElementsByClassName("recommend-right")[0];
            if(check != null ){
                check.style="display:none;";
            }
            check = document.getElementById("container");//底下广告
            if( check != null ){
                check.style="display:none;";
            }
            check = document.getElementsByClassName("p4course_target")[0];//文章底下的下一个广告
            if( check != null ){
                check.style="display:none;";
            }
            check = document.getElementsByClassName("t0 clearfix")[0];
            if( check != null ){
                check.style="display:none;";
            }
            check = document.getElementById("btnMoreComment");//评论的阅读更多
            if(check!=null){
                check.click();
            }
            csdn.copyright.init("","","");//取消剪切板附带的文字
    }
        function_CSDN();
    }


})();