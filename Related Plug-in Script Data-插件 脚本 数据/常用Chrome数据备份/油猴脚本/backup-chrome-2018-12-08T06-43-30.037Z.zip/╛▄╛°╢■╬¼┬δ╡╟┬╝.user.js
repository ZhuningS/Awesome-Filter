// ==UserScript==
// @name         拒绝二维码登录
// @namespace    NoQRCodeLogin
// @version      1.1.5
// @description  QQ、支付宝、淘宝、京东、百度云盘等网站默认使用账号密码登录，不出现二维码登录界面，原版出自https://greasyfork.org/zh-CN/scripts/27183，采用jQuery选择器重写,有需求或问题请反馈。
// @author       Eva
// @include        *://login.taobao.com/*
// @include        *://passport.jd.com/*
// @include        *://pan.baidu.com/*
// @include        *://passport.suning.com/*
// @include        *://*.alipay.com/*
// @include        https://graph.qq.com/*
// @include        *://*.weiyun.com/*
// @include        *://*.cloud.tencent.com/*
// @include        *://*.huya.com/*
// @include        *://passport.58.com/*
// @include        *://*.baixing.com/*
// @include        *://*.sl56.com/*
// @grant        unsafeWindow
// @require      https://code.jquery.com/jquery-latest.js
// @run-at 		 document-end
// ==/UserScript==

(function() {
    //淘宝
    if (isURL("login.taobao.com")) {
        var auto = setInterval(function() {
            if ($('#J_StaticForm').css('display') === 'none') {
                $('#J_Quick2Static').click();
                clearInterval(auto);
            }
        }, 50);
        return;
    }

    //京东
    if (isURL("passport.jd.com")) {
        var auto = setInterval(function() {
            if ($('.login-box').css('display') === 'none') {
                $('.login-tab-r').click();
                clearInterval(auto);
            }
        }, 50);
        return;
    }

    //百度
    if (isURL("baidu.com")) {
        var auto = setInterval(function() {
            var yunbtn = $('#TANGRAM__PSP_4__footerULoginBtn');
            var indexBtn = $('#TANGRAM__PSP_10__footerULoginBtn');
            var passportBtn = $('#TANGRAM__PSP_3__footerULoginBtn');
            var tiebaBtn = $('#TANGRAM__PSP_11__footerULoginBtn');
            var tiebaBtn2 = $('#TANGRAM__PSP_28__footerULoginBtn');
            var wenKuBtn = $('#TANGRAM__PSP_18__footerULoginBtn');
            if (yunbtn.length > 0) {
                yunbtn[0].click();
                clearInterval(auto);
            }
            if (indexBtn.length > 0) {
                indexBtn[0].click();
                clearInterval(auto);
            }
            if (passportBtn.length > 0) {
                passportBtn[0].click();
                clearInterval(auto);
            }
            if (tiebaBtn.length > 0) {
                tiebaBtn[0].click();
                clearInterval(auto);
            }
            if (tiebaBtn2.length > 0) {
                tiebaBtn2[0].click();
                clearInterval(auto);
            }
            if (wenKuBtn.length > 0) {
                wenKuBtn[0].click();
                clearInterval(auto);
            }
        }, 50);
        return;
    }

    //苏宁
    if (isURL("passport.suning.com")) {
        var auto = setInterval(function() {
            if ($('.pc-login').css('display') === 'none') {
                $('.tab-item')[1].click();
                clearInterval(auto);
            }
        }, 50);
        return;
    }

    //知乎
    if (isURL("zhihu.com")) {
        var loginDiv = $('.Login-content');
        var auto = setInterval(function() {
            if (loginDiv.length == 0) {
                $('.SignContainer-switch').children("span").click();
                clearInterval(auto);
            }
        }, 50);
        return;
    }

    //支付宝
    if (isURL("alipay.com")) {
        var auto = setInterval(function() {
            var changeTabs = $('#J-loginMethod-tabs li');
            var qrCode = $('#J-qrcode');
            var ssoLogin = $('#J-ssoLogin');
            var loginForm = $('#J-login');
            var loginFormMethod = $('#J-loginFormMethod');
            var popbox = $('#J_popbox');
            if(popbox.hasClass('stat-login')){
                var iframe = $('#J_loginIframe');
                if(iframe)
                {
                    var contentWindow = iframe[0].contentWindow;
                    if(contentWindow)
                    {
                        var loginMethod = contentWindow.document.getElementById('J-loginFormMethod');
                        if(loginMethod)
                        {
                            contentWindow.document.getElementById('J-qrcode-target').click();
                            clearInterval(auto);
                        }
                    }
                }
            }
            if (changeTabs.length >= 2) {
                changeTabs.each(function(index,element){
                    var self = $(this);
                    if((self.attr('data-status') === 'show_login') && (!self.hasClass("active"))){
                        loginFormMethod.val('');
                        qrCode.addClass('fn-hide');
                        if (window.light && window.light.page && window.light.page.products && window.light.page.products.barcode) {
                            window.light.page.products.barcode.onready(function () {
                                this.stop();
                            });
                        }
                        if (ssoLogin.attr('data-hide') === 'false' && ssoLogin.attr('data-state') === 'finished') {
                            ssoLogin.removeClass('fn-hide');
                        } else {
                            loginForm.removeClass('fn-hide');
                        }
                        self.addClass("active");
                        self.siblings().removeClass('active');
                        clearInterval(auto);
                    }
                });
            }
        }, 50);
    }

    //QQ
    if (isURL('xui.ptlogin2.qq.com') || isURL('ssl.xui.ptlogin2.qq.com') || isURL('ui.ptlogin2.qq.com')) {
        if(isURL('web2.qq.com')){
            return;
        }
        var auto = setInterval(function() {
            if ($('.onekey_logo').length == 1 || $('.face').length == 1) {
                $('#switcher_plogin')[0].click();
                $('#switcher_qlogin').on('click',function(){
                    clearInterval(auto);
                })
            }
        }, 50);
        return;
    }

    //微云
    if (isURL("weiyun.com")) {
        var auto = setInterval(function() {
            if ($('.face').length==1 && $('#bottom_qlogin').css('display') === 'block') {
                $('#switcher_plogin')[0].click();
                clearInterval(auto);
            }
        }, 50);
        return;
    }

      //腾讯云
    if (isURL("cloud.tencent.com")) {
        var auto = setInterval(function() {
            if ($('.J-wxloginBox').css('display') === 'block') {
                $('a[data-type="email"]')[0].click();
                clearInterval(auto);
            }
        }, 50);
        return;
    }

    //虎牙
    if (isURL("huya.com")) {
        var auto = setInterval(function() {
            if ($('.account').hasClass('UDBSdkLgn-none')) {
                $("img[src$='qrweb.png']").click();
                $("img[src$='webqr.png']").on('click',function(){
                    clearInterval(auto);
                })
            }
        }, 50);
        return;
    }

    //58同城
    if (isURL("passport.58.com")) {
        var auto = setInterval(function() {
            if ($('#scanCode').hasClass('hide')) {
                $('#pwdLogin').click();
                clearInterval(auto);
            }
        }, 50);
        return;
    }

    //百姓网
    if (isURL("baixing.com")) {
        var auto = setInterval(function() {
            if ($('.login-window a[href="#appLogin"]').closest('li').hasClass('active')) {
                $('.login-window a[href="#mobile"]')[0].click();
                clearInterval(auto);
            }
        }, 50);
        return;
    }

    //升蓝物流
    if (isURL("sl56.com")) {
        var auto = setInterval(function() {
            if ($('#password').css('display') === 'none') {
                $('#btnPassword').click();
                clearInterval(auto);
            }
        }, 50);
        return;
    }

    //判断网址
    function isURL(x){
        return window.location.href.indexOf(x) != -1;
    }

    //alert
    function pop(x){
        if(x){
            alert(x);
        }else{
            alert("控制台测试");
        }
    }

    //console
    function log(x){
        if(x){
            console.log(x);
        }else{
            console.log("控制台测试");
        }
    }
})();