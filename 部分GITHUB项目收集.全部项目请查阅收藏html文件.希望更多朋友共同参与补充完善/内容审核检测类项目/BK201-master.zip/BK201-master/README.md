# Kuma

> [Nuxt.js SPA mode v.2.3.4](https://github.com/nuxt/nuxt.js/releases/tag/v2.3.4) + [vue-element-admin v3.9.3](https://github.com/PanJiaChen/vue-element-admin/releases/tag/v3.9.3)

## Build Setup

``` bash
# install dependencies
$ yarn install

# serve with hot reload at localhost:9092
$ yarn run dev

# build for production and launch server
$ yarn run build
$ yarn start

# generate static project
$ yarn run generate
```

For detailed explanation on how things work, checkout [Nuxt.js docs](https://nuxtjs.org).
