<style lang="scss">
</style>

<template>
  <div id="log-text">
    LogText
  </div>
</template>

<script>
export default {
  name: 'LogText',
  components: {},
  props: {},
  data() {
    return {}
  },
  computed: {},
  watch: {},
  created() {},
  mounted() {},
  methods: {}
}
</script>
