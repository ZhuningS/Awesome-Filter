<style lang="scss">
</style>

<template>
  <div id="log-user">
    LogUser
  </div>
</template>

<script>
export default {
  name: 'LogUser',
  components: {},
  props: {},
  data() {
    return {}
  },
  computed: {},
  watch: {},
  created() {},
  mounted() {},
  methods: {}
}
</script>
