<style lang="scss">
</style>

<template>
  <div id="blacklist-edit">
    BlacklistEdit
  </div>
</template>

<script>
export default {
  name: 'BlacklistEdit',
  components: {},
  props: {},
  data() {
    return {}
  },
  computed: {},
  watch: {},
  created() {},
  mounted() {},
  methods: {}
}
</script>
