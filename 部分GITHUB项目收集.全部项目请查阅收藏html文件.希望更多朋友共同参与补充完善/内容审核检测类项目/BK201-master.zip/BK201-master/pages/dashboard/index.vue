<template>
  <div id="dashboard">
    index
  </div>
</template>

<script>
export default {
  components: {}
}
</script>
