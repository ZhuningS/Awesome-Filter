<style lang="scss">
</style>

<template>
  <div id="report-manager">
    举报管理
  </div>
</template>

<script>
export default {
  name: 'ReportManager',
  components: {},
  props: {},
  data() {
    return {}
  },
  computed: {},
  watch: {},
  created() {},
  mounted() {},
  methods: {}
}
</script>
