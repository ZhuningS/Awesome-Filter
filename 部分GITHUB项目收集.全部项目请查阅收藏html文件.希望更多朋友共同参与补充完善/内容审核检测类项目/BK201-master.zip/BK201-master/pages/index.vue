<template>
  <div/>
</template>

<script>
export default {
  asyncData({ redirect }) {
    redirect('/dashboard/')
  }
}
</script>
