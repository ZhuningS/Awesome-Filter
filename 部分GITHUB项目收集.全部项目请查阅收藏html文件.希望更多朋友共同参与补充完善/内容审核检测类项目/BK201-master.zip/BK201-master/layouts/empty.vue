<template>
  <nuxt/>
</template>
