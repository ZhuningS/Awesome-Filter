# triggerBlocker
Chrome extension that allows people to filter FB posts with trigger warnings and/or specific terms
