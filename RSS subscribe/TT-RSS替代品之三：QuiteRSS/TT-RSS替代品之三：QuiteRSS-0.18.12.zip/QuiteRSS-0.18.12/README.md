[![Build Status](https://travis-ci.org/QuiteRSS/quiterss.svg?branch=master)](https://travis-ci.org/QuiteRSS/quiterss)
[![Build status](https://ci.appveyor.com/api/projects/status/5lr4m5jxf2ad4f5r/branch/master?svg=true)](https://ci.appveyor.com/project/Funcy-dcm/quiterss/branch/master)
[![Codacy Badge](https://api.codacy.com/project/badge/Grade/ed6473aef4dd4c5aba8cf1dbbc8c6383)](https://www.codacy.com/app/Funcy-dcm/quiterss?utm_source=github.com&utm_medium=referral&utm_content=QuiteRSS/quiterss&utm_campaign=badger)

Copyright (C) 2011-2018 QuiteRSS Team <quiterssteam@gmail.com>

QuiteRSS is a open-source cross-platform RSS/Atom news feeds reader written on Qt/C++

Idea: Quite fast and comfortable to user

Links:
* Website: https://quiterss.org
* Git repository: https://github.com/QuiteRSS/quiterss
* Issue tracker: https://github.com/QuiteRSS/quiterss/issues
* Translations: https://www.transifex.com/projects/p/quiterss/
