## Contributing code the right way 

TLDR: it works pretty much like Github.

1. Make an account on Gogs
2. Fork the repository you're interested in (also see below)
3. Do the needful
4. File a pull request with your changes against master branch.

**If you can't fork the repository on Gogs, please see this forum thread:**

https://discourse.tt-rss.org/t/pull-requests-gogs-spam/1850/2


