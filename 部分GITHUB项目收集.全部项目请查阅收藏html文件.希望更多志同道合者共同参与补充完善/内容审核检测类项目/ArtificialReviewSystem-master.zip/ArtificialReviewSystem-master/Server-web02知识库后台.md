### Server-web02知识库后台
## 基本信息
1. ip 40.73.102.21
1. 端口号：22 80
1. [地址](http://40.73.102.21):http://40.73.102.21
1. 项目地址：/mnt/apache-tomcat-9.0.12/webapps/xuhuiCMS/
