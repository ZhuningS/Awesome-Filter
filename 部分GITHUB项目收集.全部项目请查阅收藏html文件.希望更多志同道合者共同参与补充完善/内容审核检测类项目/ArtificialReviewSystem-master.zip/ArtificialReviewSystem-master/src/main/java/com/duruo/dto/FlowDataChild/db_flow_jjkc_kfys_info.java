package com.duruo.dto.FlowDataChild;

import lombok.Data;

/**
 * Created by @Author tachai
 * date 2018/6/27 10:37
 *
 * @Email 1206966083@qq.com
 */
@Data
public class db_flow_jjkc_kfys_info {
    private String Id;
    private String Num;
    private String DecomposeDetailed;
    private String SpecialFunds;
    private String SelfFinancing;
    private String Remark;
}
