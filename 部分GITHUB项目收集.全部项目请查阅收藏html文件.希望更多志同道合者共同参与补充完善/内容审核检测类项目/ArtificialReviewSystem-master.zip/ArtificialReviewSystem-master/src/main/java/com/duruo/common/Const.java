package com.duruo.common;

/**
 * Created by @Author tachai
 * date 2018/6/10 17:06
 *
 * @Email 1206966083@qq.com
 */
public class Const {
    public static final String CURRENT_USER="currentUser";
    public static final String USERNAME="username";

    public  interface  Role{
        int ROLE_CUSTOMER=0;//普通用户
        int ROLE_ADMIN=1;//管理员
    }
}
