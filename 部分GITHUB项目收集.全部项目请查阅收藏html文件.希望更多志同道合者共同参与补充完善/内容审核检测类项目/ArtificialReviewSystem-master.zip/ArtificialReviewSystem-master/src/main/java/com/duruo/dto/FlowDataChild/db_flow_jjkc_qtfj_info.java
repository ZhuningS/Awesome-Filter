package com.duruo.dto.FlowDataChild;

import lombok.Data;

/**
 * Created by @Author tachai
 * date 2018/6/27 10:38
 *
 * @Email 1206966083@qq.com
 */
@Data
public class db_flow_jjkc_qtfj_info {
    private String Id;
    private String TypeCode;
    private String Num;
    private String FileName;
    private String Remark;
}
