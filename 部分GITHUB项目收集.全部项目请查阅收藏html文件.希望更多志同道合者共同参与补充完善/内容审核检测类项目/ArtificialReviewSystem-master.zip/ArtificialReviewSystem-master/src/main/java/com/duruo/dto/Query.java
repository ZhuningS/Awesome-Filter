package com.duruo.dto;

import lombok.Data;

/**
 * Created by @Author tachai
 * date 2018/8/14 15:34
 * GitHub https://github.com/TACHAI
 * Email 1206966083@qq.com
 */
@Data
public class Query {
    private String query;
    private String userId;
}
