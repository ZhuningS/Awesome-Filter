package com.duruo.vo;

import com.duruo.po.*;
import lombok.Data;

/**
 * Created by @Author tachai
 * date 2018/9/25 19:52
 * GitHub https://github.com/TACHAI
 * Email 1206966083@qq.com
 */
//这里是给页面展现用的
@Data
public class QchaungVO extends com.duruo.po.Qchuang {
    private String age;
    private String applyDate;
    private String applyDate1;

}
