@javax.xml.bind.annotation.XmlSchema(namespace = "http://cxf.service.webucp.wondersgroup.com/")
package com.duruo.webserviceClient.xuhuisms;
