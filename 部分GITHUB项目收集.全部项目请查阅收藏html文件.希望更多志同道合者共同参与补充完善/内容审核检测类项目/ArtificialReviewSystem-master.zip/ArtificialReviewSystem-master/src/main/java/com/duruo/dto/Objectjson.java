package com.duruo.dto;

import com.google.gson.JsonObject;
import lombok.Data;

/**
 * Created by @Author tachai
 * date 2018/7/13 19:38
 *
 * @Email 1206966083@qq.com
 */
@Data
public class Objectjson {
    private String key;
    private JsonObject jsonObject;
}
