package com.duruo.common;

/**
 * Created by @Author tachai
 * date 2018/7/7 14:05
 *
 * @Email 1206966083@qq.com
 */
//存放事项模板名称
public interface MatterCode {
 String APPLY_LIQUOR = "徐汇区酒类商品零售许可证申请表.ftl";
 String PUBLIC_PLACE_HEALTH_PERMIT = "上海市公共场所卫生许可证申请书.ftl";
 String OTHER_WORKING_HOURS_APPLY = "企业实行不定时工作制和综合计算工时工作制申请表.ftl";
 String ELECTRONIC_DIGITAL = "上海市法人一证通数字证书申请表.ftl";
 String SPECIAL_EQUIPMENT1 = "特种设备使用登记按台数.ftl";
 String SPECIAL_EQUIPMENT2 = "特种设备使用登记按单位.ftl";
 String RECORD_REGISTRATION_OF_MIGRANT_WORKERS = "外来从业人员用工备案登记表.ftl";
 String PERSONAL_INFORMATION_COLLECTION = "个人基本信息采集（变更）.ftl";
}
