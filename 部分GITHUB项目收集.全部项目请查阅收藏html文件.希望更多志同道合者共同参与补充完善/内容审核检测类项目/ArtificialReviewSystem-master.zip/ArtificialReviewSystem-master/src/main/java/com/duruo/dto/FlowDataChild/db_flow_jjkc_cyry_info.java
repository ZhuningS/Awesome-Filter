package com.duruo.dto.FlowDataChild;

import lombok.Data;

/**
 * Created by @Author tachai
 * date 2018/6/27 10:37
 *
 * @Email 1206966083@qq.com
 */
@Data
public class db_flow_jjkc_cyry_info {
    private String Id;
    private String Num;
    private String Name;
    private String Age;
    private String Education;
    private String MajorName;
    private String Post;
    private String WorkingHours;
    private String Remark;
}
