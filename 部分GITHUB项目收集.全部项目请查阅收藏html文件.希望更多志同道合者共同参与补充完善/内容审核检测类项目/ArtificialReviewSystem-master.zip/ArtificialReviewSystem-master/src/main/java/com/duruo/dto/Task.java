package com.duruo.dto;

import lombok.Data;

/**
 * Created by @Author tachai
 * date 2018/7/12 14:59
 *
 * @Email 1206966083@qq.com
 */
//构造请求对话中json
@Data
public class Task {
    private String userId;
    private String taskName;
}
