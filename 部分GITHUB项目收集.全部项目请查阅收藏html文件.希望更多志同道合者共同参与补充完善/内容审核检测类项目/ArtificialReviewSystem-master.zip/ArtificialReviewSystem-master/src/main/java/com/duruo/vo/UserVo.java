package com.duruo.vo;

import com.duruo.po.UserPo;
import lombok.Data;

/**
 * Created by @Author tachai
 * date 2018/6/14 20:18
 *
 * @Email 1206966083@qq.com
 */
@Data
public class UserVo extends UserPo{
    private String deptName;
}
