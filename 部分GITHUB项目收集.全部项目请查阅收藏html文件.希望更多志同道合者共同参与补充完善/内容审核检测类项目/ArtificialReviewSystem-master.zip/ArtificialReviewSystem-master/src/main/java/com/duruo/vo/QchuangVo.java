package com.duruo.vo;

import lombok.Data;

/**
 * Created by @Author tachai
 * date 2018/9/20 15:37
 * GitHub https://github.com/TACHAI
 * Email 1206966083@qq.com
 */
@Data
public class QchuangVo {
    private String queryInfo;
    private String userId;
}
