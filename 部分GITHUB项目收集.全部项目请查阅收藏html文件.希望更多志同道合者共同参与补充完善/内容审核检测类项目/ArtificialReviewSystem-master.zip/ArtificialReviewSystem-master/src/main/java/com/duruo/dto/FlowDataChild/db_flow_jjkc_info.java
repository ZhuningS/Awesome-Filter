package com.duruo.dto.FlowDataChild;

import lombok.Data;

/**
 * Created by @Author tachai
 * date 2018/6/27 10:36
 *
 * @Email 1206966083@qq.com
 */
@Data
public class db_flow_jjkc_info {
    private String Title;
    private String Status;
    private String StatusCode;
    private String ModifyTime;
    private String ProjectCode;
    private String TechnicalFieldCode;
    private String TechnicalField;
    private String checkbox1;
    private String checkbox2;
    private String SHYJ;
    private String SHYJTzqy;
    private String SHYJ1;
    private String SHYJ2;
}
