<template>
  <subHeader subHeader="未接单的战报"/>
</template>

<script>
import subHeader from 'src/components/global/sub-header';

export default {
  components: {
    subHeader
  }
};
</script>
