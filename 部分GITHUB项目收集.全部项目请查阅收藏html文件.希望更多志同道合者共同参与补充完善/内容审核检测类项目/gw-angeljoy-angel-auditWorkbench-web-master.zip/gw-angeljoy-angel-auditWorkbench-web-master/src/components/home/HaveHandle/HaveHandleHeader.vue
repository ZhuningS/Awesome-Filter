<template>
  <subHeader subHeader="已处理战报结果"/>
</template>

<script>
import subHeader from 'src/components/global/sub-header';

export default {
  components: {
    subHeader
  }
};
</script>
