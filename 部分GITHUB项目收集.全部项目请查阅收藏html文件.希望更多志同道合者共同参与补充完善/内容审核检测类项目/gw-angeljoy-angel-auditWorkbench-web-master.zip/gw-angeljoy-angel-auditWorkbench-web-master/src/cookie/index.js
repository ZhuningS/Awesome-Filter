/*
 * cookie 使用情况
 */

export default {
  userId: 'userId', // ---用户id,,在注册成功后，后台自动设置
  userName: 'userName', // ---用户名，在注册成功后，后台自动设置
  auth: 'auth' // ---在注册成功后，后台自动设置
};
